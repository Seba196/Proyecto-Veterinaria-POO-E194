/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import dao.CategoriaDAO;
import modelo.Categoria;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class CategoriaVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CategoriaVista.class.getName());
    private JTextField txtNombre;
    private JTextArea  txtDescripcion;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private CategoriaDAO dao;
    private int idSeleccionado = -1;
    
    /**
     * Creates new form CategoriaVista
     */
    public CategoriaVista() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        dao = new CategoriaDAO();
        setTitle("Gestion de Categorias");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- FORMULARIO ---
        JPanel panelForm = new JPanel(new GridLayout(4, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos de la Categoria"));
        panelForm.setPreferredSize(new Dimension(280, 180));

        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelForm.add(txtNombre);

        panelForm.add(new JLabel("Descripcion:"));
        txtDescripcion = new JTextArea(3, 15);
        txtDescripcion.setLineWrap(true);
        panelForm.add(new JScrollPane(txtDescripcion));

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new GridLayout(2, 3, 5, 5));
        JButton btnGuardar    = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar   = new JButton("Eliminar");
        JButton btnLimpiar    = new JButton("Limpiar");
        JButton btnVolver     = new JButton("< Volver");

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVolver);

        // --- TABLA ---
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Descripcion"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Categorias registradas"));

        // --- PANEL IZQUIERDO ---
        JPanel panelIzq = new JPanel(new BorderLayout(5, 5));
        panelIzq.add(panelForm,    BorderLayout.CENTER);
        panelIzq.add(panelBotones, BorderLayout.SOUTH);
        panelIzq.setPreferredSize(new Dimension(290, 450));

        add(panelIzq, BorderLayout.WEST);
        add(scroll,   BorderLayout.CENTER);

        cargarTabla();

        // --- SELECCIONAR FILA ---
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int fila = tabla.getSelectedRow();
                if (fila >= 0) {
                    idSeleccionado = (int) modeloTabla.getValueAt(fila, 0);
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtDescripcion.setText(modeloTabla.getValueAt(fila, 2).toString());
                }
            }
        });

        // --- ACCIONES ---
        btnGuardar.addActionListener(e -> {
            Categoria c = new Categoria(0, txtNombre.getText(), txtDescripcion.getText());
            if (dao.agregar(c)) {
                JOptionPane.showMessageDialog(this, "Categoria guardada");
                cargarTabla();
                limpiar();
            }
        });

        btnActualizar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona una categoria");
                return;
            }
            Categoria c = new Categoria(idSeleccionado,
                txtNombre.getText(), txtDescripcion.getText());
            if (dao.actualizar(c)) {
                JOptionPane.showMessageDialog(this, "Categoria actualizada");
                cargarTabla();
                limpiar();
            }
        });

        btnEliminar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona una categoria");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(
                this, "¿Eliminar esta categoria?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (dao.eliminar(idSeleccionado)) {
                    JOptionPane.showMessageDialog(this, "Categoria eliminada");
                    cargarTabla();
                    limpiar();
                }
            }
        });

        btnLimpiar.addActionListener(e -> limpiar());
        btnVolver.addActionListener(e -> this.dispose());
    }

    private void cargarTabla() {
        modeloTabla.setRowCount(0);
        List<Categoria> lista = dao.listar();
        for (Categoria c : lista) {
            modeloTabla.addRow(new Object[]{
                c.getIdCategoria(), c.getNombre(), c.getDescripcion()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtDescripcion.setText("");
        idSeleccionado = -1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CategoriaVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
