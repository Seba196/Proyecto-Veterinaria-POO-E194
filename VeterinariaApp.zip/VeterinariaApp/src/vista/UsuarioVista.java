/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import dao.UsuarioDAO;
import modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class UsuarioVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(UsuarioVista.class.getName());
    
    private JTextField txtNombre, txtCorreo, txtTelefono, txtContrasena, txtRol;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private UsuarioDAO dao;
    private int idSeleccionado = -1;
    /**
     * Creates new form UsuarioVista
     */
    public UsuarioVista() {
        initComponents();
        dao = new UsuarioDAO();
        setTitle("Gestión de Usuarios");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- FORMULARIO ---
        JPanel panelForm = new JPanel(new GridLayout(6, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Usuario"));

        panelForm.add(new JLabel("Nombre:"));
        txtNombre     = new JTextField();
        panelForm.add(txtNombre);

        panelForm.add(new JLabel("Correo:"));
        txtCorreo     = new JTextField();
        panelForm.add(txtCorreo);

        panelForm.add(new JLabel("Teléfono:"));
        txtTelefono   = new JTextField();
        panelForm.add(txtTelefono);

        panelForm.add(new JLabel("Contraseña:"));
        txtContrasena = new JTextField();
        panelForm.add(txtContrasena);

        panelForm.add(new JLabel("Rol:"));
        txtRol        = new JTextField();
        panelForm.add(txtRol);

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar    = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar   = new JButton("Eliminar");
        JButton btnLimpiar    = new JButton("Limpiar");
        JButton btnVolver     = new JButton("< Volver");

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVolver);

        // --- TABLA ---
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Correo", "Teléfono", "Rol"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tabla);

        // --- PANEL IZQUIERDO ---
        JPanel panelIzq = new JPanel(new BorderLayout());
        panelIzq.add(panelForm,    BorderLayout.CENTER);
        panelIzq.add(panelBotones, BorderLayout.SOUTH);

        add(panelIzq, BorderLayout.WEST);
        add(scroll,   BorderLayout.CENTER);

        // --- CARGAR TABLA AL ABRIR ---
        cargarTabla();

        // --- SELECCIONAR FILA ---
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int fila = tabla.getSelectedRow();
                if (fila >= 0) {
                    idSeleccionado = (int) modeloTabla.getValueAt(fila, 0);
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtCorreo.setText(modeloTabla.getValueAt(fila, 2).toString());
                    txtTelefono.setText(modeloTabla.getValueAt(fila, 3).toString());
                    txtRol.setText(modeloTabla.getValueAt(fila, 4).toString());
                }
            }
        });

        // --- ACCIÓN GUARDAR ---
        btnGuardar.addActionListener(e -> {
            Usuario u = new Usuario(0,
                txtNombre.getText(), txtCorreo.getText(),
                txtTelefono.getText(), txtContrasena.getText(),
                txtRol.getText());
            if (dao.agregar(u)) {
                JOptionPane.showMessageDialog(this, "Usuario guardado");
                cargarTabla();
                limpiar();
            }
        });

        // --- ACCIÓN ACTUALIZAR ---
        btnActualizar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un usuario");
                return;
            }
            Usuario u = new Usuario(idSeleccionado,
                txtNombre.getText(), txtCorreo.getText(),
                txtTelefono.getText(), txtContrasena.getText(),
                txtRol.getText());
            if (dao.actualizar(u)) {
                JOptionPane.showMessageDialog(this, "Usuario actualizado");
                cargarTabla();
                limpiar();
            }
        });

        // --- ACCIÓN ELIMINAR ---
        btnEliminar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un usuario");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(
                this, "¿Seguro que deseas eliminar este usuario?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (dao.eliminar(idSeleccionado)) {
                    JOptionPane.showMessageDialog(this, "Usuario eliminado");
                    cargarTabla();
                    limpiar();
                }
            }
        });

        // --- ACCIÓN LIMPIAR ---
        btnLimpiar.addActionListener(e -> limpiar());
        
        // --- ACCION VOLVER ---
        btnVolver.addActionListener(e -> {
        this.dispose(); // cierra esta ventana y vuelve al menu
});
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>    
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new UsuarioVista().setVisible(true));
    }
    private void cargarTabla() {
        modeloTabla.setRowCount(0);
        List<Usuario> lista = dao.listar();
        for (Usuario u : lista) {
            modeloTabla.addRow(new Object[]{
                u.getIdUsuario(), u.getNombre(),
                u.getCorreo(),    u.getTelefono(),
                u.getRol()
            });
        }
    }

    //Método para limpiar el formulario
    private void limpiar() {
        txtNombre.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");
        txtContrasena.setText("");
        txtRol.setText("");
        idSeleccionado = -1;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
