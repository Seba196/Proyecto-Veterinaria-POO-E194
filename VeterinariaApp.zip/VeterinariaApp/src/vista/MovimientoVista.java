/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import dao.MovimientoDAO;
import modelo.Movimiento;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class MovimientoVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MovimientoVista.class.getName());
    
    private JComboBox<String> cmbProducto, cmbUsuario, cmbTipo;
    private JTextField txtCantidad, txtFiltroProducto, txtFiltroDesde, txtFiltroHasta;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private MovimientoDAO dao;
    private int idProductoSeleccionado = -1;
    private int idUsuarioSeleccionado  = -1;
    
    /**
     * Creates new form MovimientoVista
     */
    public MovimientoVista() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        dao = new MovimientoDAO();
        setTitle("Registro de Movimientos de Stock");
        setSize(1000, 580);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ============================================
        // PANEL IZQUIERDO — Registrar movimiento
        // ============================================
        JPanel panelForm = new JPanel(new GridLayout(6, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createTitledBorder("Registrar Movimiento"));

        panelForm.add(new JLabel("Producto:"));
        cmbProducto = new JComboBox<>();
        panelForm.add(cmbProducto);

        panelForm.add(new JLabel("Usuario:"));
        cmbUsuario = new JComboBox<>();
        panelForm.add(cmbUsuario);

        panelForm.add(new JLabel("Tipo:"));
        cmbTipo = new JComboBox<>(new String[]{"entrada", "salida"});
        panelForm.add(cmbTipo);

        panelForm.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelForm.add(txtCantidad);

        cargarCombos();

        // Botones registrar y volver
        JPanel panelBotReg = new JPanel(new GridLayout(1, 2, 5, 5));
        JButton btnRegistrar = new JButton("Registrar");
        JButton btnVolver    = new JButton("< Volver");
        panelBotReg.add(btnRegistrar);
        panelBotReg.add(btnVolver);

        JPanel panelIzq = new JPanel(new BorderLayout(5, 5));
        panelIzq.add(panelForm,    BorderLayout.CENTER);
        panelIzq.add(panelBotReg,  BorderLayout.SOUTH);
        panelIzq.setPreferredSize(new Dimension(280, 580));

        // ============================================
        // PANEL DERECHO — Historial con filtros
        // ============================================
        JPanel panelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
        panelFiltros.setBorder(BorderFactory.createTitledBorder("Filtrar historial"));

        panelFiltros.add(new JLabel("Producto:"));
        txtFiltroProducto = new JTextField(10);
        panelFiltros.add(txtFiltroProducto);

        panelFiltros.add(new JLabel("Desde (YYYY-MM-DD):"));
        txtFiltroDesde = new JTextField(10);
        panelFiltros.add(txtFiltroDesde);

        panelFiltros.add(new JLabel("Hasta (YYYY-MM-DD):"));
        txtFiltroHasta = new JTextField(10);
        panelFiltros.add(txtFiltroHasta);

        JButton btnFiltrar = new JButton("Buscar");
        JButton btnLimpiarFiltro = new JButton("Ver todo");
        panelFiltros.add(btnFiltrar);
        panelFiltros.add(btnLimpiarFiltro);

        // Tabla de historial
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Tipo", "Producto", "Cantidad", "Usuario", "Fecha"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        tabla = new JTable(modeloTabla);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(150);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(70);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(120);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(150);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Historial de movimientos"));

        JPanel panelDer = new JPanel(new BorderLayout(5, 5));
        panelDer.add(panelFiltros, BorderLayout.NORTH);
        panelDer.add(scroll,       BorderLayout.CENTER);

        add(panelIzq, BorderLayout.WEST);
        add(panelDer, BorderLayout.CENTER);

        cargarTabla(null, null, null);

        // ============================================
        // ACCIONES
        // ============================================
        btnRegistrar.addActionListener(e -> {
            if (idProductoSeleccionado == -1 || idUsuarioSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona producto y usuario");
                return;
            }
            if (txtCantidad.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa una cantidad");
                return;
            }
            try {
                Movimiento m = new Movimiento();
                m.setTipo(cmbTipo.getSelectedItem().toString());
                m.setCantidad(Integer.parseInt(txtCantidad.getText()));
                m.setIdProducto(idProductoSeleccionado);
                m.setIdUsuario(idUsuarioSeleccionado);

                if (dao.registrar(m)) {
                    JOptionPane.showMessageDialog(this, "Movimiento registrado y stock actualizado");
                    txtCantidad.setText("");
                    cargarTabla(null, null, null);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser un numero entero");
            }
        });

        btnFiltrar.addActionListener(e -> {
            cargarTabla(
                txtFiltroProducto.getText(),
                txtFiltroDesde.getText(),
                txtFiltroHasta.getText()
            );
        });

        btnLimpiarFiltro.addActionListener(e -> {
            txtFiltroProducto.setText("");
            txtFiltroDesde.setText("");
            txtFiltroHasta.setText("");
            cargarTabla(null, null, null);
        });

        btnVolver.addActionListener(e -> this.dispose());
    }

    private void cargarCombos() {
        List<String[]> productos = dao.listarProductos();
        for (String[] p : productos) {
            cmbProducto.addItem(p[1]);
        }
        List<String[]> usuarios = dao.listarUsuarios();
        for (String[] u : usuarios) {
            cmbUsuario.addItem(u[1]);
        }

        cmbProducto.addActionListener(e -> {
            int idx = cmbProducto.getSelectedIndex();
            if (idx >= 0) {
                idProductoSeleccionado = Integer.parseInt(
                    dao.listarProductos().get(idx)[0]);
            }
        });

        cmbUsuario.addActionListener(e -> {
            int idx = cmbUsuario.getSelectedIndex();
            if (idx >= 0) {
                idUsuarioSeleccionado = Integer.parseInt(
                    dao.listarUsuarios().get(idx)[0]);
            }
        });

        // Inicializar con el primer elemento
        if (cmbProducto.getItemCount() > 0) {
            idProductoSeleccionado = Integer.parseInt(
                dao.listarProductos().get(0)[0]);
        }
        if (cmbUsuario.getItemCount() > 0) {
            idUsuarioSeleccionado = Integer.parseInt(
                dao.listarUsuarios().get(0)[0]);
        }
    }

    private void cargarTabla(String producto, String desde, String hasta) {
        modeloTabla.setRowCount(0);
        List<Movimiento> lista = dao.listarFiltrado(producto, desde, hasta);
        for (Movimiento m : lista) {
            modeloTabla.addRow(new Object[]{
                m.getIdMovimiento(),
                m.getTipo().toUpperCase(),
                m.getNombreProducto(),
                m.getCantidad(),
                m.getNombreUsuario(),
                m.getFecha()
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MovimientoVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
