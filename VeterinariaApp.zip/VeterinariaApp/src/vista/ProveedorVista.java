/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import dao.ProveedorDAO;
import modelo.Proveedor;
import modelo.Producto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ProveedorVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ProveedorVista.class.getName());
    
    private JTextField txtNombre, txtTelefono, txtCorreo, txtDireccion;
    private JTable tablaProveedores, tablaProductos;
    private DefaultTableModel modeloProveedores, modeloProductos;
    private ProveedorDAO dao;
    private int idSeleccionado = -1;
    
    /**
     * Creates new form ProveedorVista
     */
    public ProveedorVista() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        dao = new ProveedorDAO();
        setTitle("Gestion de Proveedores");
        setSize(1000, 580);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- FORMULARIO ---
        JPanel panelForm = new JPanel(new GridLayout(5, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Proveedor"));
        panelForm.setPreferredSize(new Dimension(300, 200));

        panelForm.add(new JLabel("Nombre:"));
        txtNombre    = new JTextField();
        panelForm.add(txtNombre);

        panelForm.add(new JLabel("Telefono:"));
        txtTelefono  = new JTextField();
        panelForm.add(txtTelefono);

        panelForm.add(new JLabel("Correo:"));
        txtCorreo    = new JTextField();
        panelForm.add(txtCorreo);

        panelForm.add(new JLabel("Direccion:"));
        txtDireccion = new JTextField();
        panelForm.add(txtDireccion);

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new GridLayout(2, 3, 5, 5));
        JButton btnGuardar    = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar   = new JButton("Eliminar");
        JButton btnLimpiar    = new JButton("Limpiar");
        JButton btnVolver     = new JButton("< Volver");
        

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVolver);

        // --- TABLA PROVEEDORES (izquierda arriba) ---
        modeloProveedores = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Telefono", "Correo", "Direccion"}, 0);
        tablaProveedores = new JTable(modeloProveedores);
        JScrollPane scrollProv = new JScrollPane(tablaProveedores);
        scrollProv.setBorder(BorderFactory.createTitledBorder("Proveedores registrados"));
        scrollProv.setPreferredSize(new Dimension(300, 200));

        // --- TABLA PRODUCTOS DEL PROVEEDOR (derecha) ---
        modeloProductos = new DefaultTableModel(
            new String[]{"ID", "Producto", "Categoria", "Precio", "Stock"}, 0);
        tablaProductos = new JTable(modeloProductos);
        JScrollPane scrollProd = new JScrollPane(tablaProductos);
        scrollProd.setBorder(BorderFactory.createTitledBorder("Productos del proveedor seleccionado"));

        // --- PANEL IZQUIERDO ---
        JPanel panelIzq = new JPanel(new BorderLayout(5, 5));
        panelIzq.add(panelForm,    BorderLayout.NORTH);
        panelIzq.add(scrollProv,   BorderLayout.CENTER);
        panelIzq.add(panelBotones, BorderLayout.SOUTH);
        panelIzq.setPreferredSize(new Dimension(340, 580));

        add(panelIzq,   BorderLayout.WEST);
        add(scrollProd, BorderLayout.CENTER);

        cargarTabla();

        // --- SELECCIONAR PROVEEDOR Y MOSTRAR SUS PRODUCTOS ---
        tablaProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int fila = tablaProveedores.getSelectedRow();
                if (fila >= 0) {
                    idSeleccionado = (int) modeloProveedores.getValueAt(fila, 0);
                    txtNombre.setText(modeloProveedores.getValueAt(fila, 1).toString());
                    txtTelefono.setText(modeloProveedores.getValueAt(fila, 2).toString());
                    txtCorreo.setText(modeloProveedores.getValueAt(fila, 3).toString());
                    txtDireccion.setText(modeloProveedores.getValueAt(fila, 4).toString());
                    // Cargar productos de ese proveedor
                    cargarProductosProveedor(idSeleccionado);
                }
            }
        });

        // --- ACCIONES ---
        btnGuardar.addActionListener(e -> {
            Proveedor p = new Proveedor(0,
                txtNombre.getText(), txtTelefono.getText(),
                txtCorreo.getText(), txtDireccion.getText());
            if (dao.agregar(p)) {
                JOptionPane.showMessageDialog(this, "Proveedor guardado");
                cargarTabla();
                limpiar();
            }
        });

        btnActualizar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un proveedor");
                return;
            }
            Proveedor p = new Proveedor(idSeleccionado,
                txtNombre.getText(), txtTelefono.getText(),
                txtCorreo.getText(), txtDireccion.getText());
            if (dao.actualizar(p)) {
                JOptionPane.showMessageDialog(this, "Proveedor actualizado");
                cargarTabla();
                limpiar();
            }
        });

        btnEliminar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un proveedor");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(
                this, "¿Eliminar este proveedor?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (dao.eliminar(idSeleccionado)) {
                    JOptionPane.showMessageDialog(this, "Proveedor eliminado");
                    cargarTabla();
                    limpiar();
                }
            }
        });

        btnLimpiar.addActionListener(e -> limpiar());
        btnVolver.addActionListener(e -> this.dispose());
    }

    private void cargarTabla() {
        modeloProveedores.setRowCount(0);
        List<Proveedor> lista = dao.listar();
        for (Proveedor p : lista) {
            modeloProveedores.addRow(new Object[]{
                p.getIdProveedor(), p.getNombre(),
                p.getTelefono(),    p.getCorreo(),
                p.getDireccion()
            });
        }
    }

    private void cargarProductosProveedor(int idProveedor) {
        modeloProductos.setRowCount(0);
        List<Producto> lista = dao.listarProductosPorProveedor(idProveedor);
        for (Producto p : lista) {
            modeloProductos.addRow(new Object[]{
                p.getIdProducto(),
                p.getNombre(),
                p.getNombreCategoria(),
                String.format("$ %,.0f", p.getPrecio()),
                p.getStock()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        idSeleccionado = -1;
        modeloProductos.setRowCount(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException |
                 javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ProveedorVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
