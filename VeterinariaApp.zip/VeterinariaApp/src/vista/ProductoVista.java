/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import dao.ProductoDAO;
import modelo.Producto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ProductoVista extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ProductoVista.class.getName());
    
    private JTextField txtNombre, txtDescripcion, txtPrecio, txtStock, txtFecha;
    private JComboBox<String> cmbProveedor, cmbCategoria;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private ProductoDAO dao;
    private int idSeleccionado = -1;
    private int idProveedorSeleccionado = -1;
    private int idCategoriaSeleccionada = -1;
    
    /**
     * Creates new form ProductoVista
     */
    public ProductoVista() {
        initComponents();
        dao = new ProductoDAO();
        setTitle("Gestion de Productos");
        setSize(950, 550);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- FORMULARIO ---
        JPanel panelForm = new JPanel(new GridLayout(8, 2, 5, 5));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Producto"));
        panelForm.setPreferredSize(new Dimension(320, 400));

        panelForm.add(new JLabel("Nombre:"));
        txtNombre      = new JTextField();
        panelForm.add(txtNombre);

        panelForm.add(new JLabel("Descripcion:"));
        txtDescripcion = new JTextField();
        panelForm.add(txtDescripcion);

        panelForm.add(new JLabel("Precio:"));
        txtPrecio      = new JTextField();
        panelForm.add(txtPrecio);

        panelForm.add(new JLabel("Stock:"));
        txtStock       = new JTextField();
        panelForm.add(txtStock);

        panelForm.add(new JLabel("Fecha Vencimiento (YYYY-MM-DD):"));
        txtFecha       = new JTextField();
        panelForm.add(txtFecha);

        panelForm.add(new JLabel("Proveedor:"));
        cmbProveedor   = new JComboBox<>();
        panelForm.add(cmbProveedor);

        panelForm.add(new JLabel("Categoria:"));
        cmbCategoria   = new JComboBox<>();
        panelForm.add(cmbCategoria);

        // Cargar combos
        cargarCombos();

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar    = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar   = new JButton("Eliminar");
        JButton btnLimpiar    = new JButton("Limpiar");
        JButton btnVolver     = new JButton("< Volver");

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnVolver);

        // --- TABLA ---
        modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Descripcion", "Precio",
                         "Stock", "Vencimiento", "Proveedor", "Categoria"}, 0);
        tabla = new JTable(modeloTabla);
        tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        JScrollPane scroll = new JScrollPane(tabla);

        // --- PANEL IZQUIERDO ---
        JPanel panelIzq = new JPanel(new BorderLayout());
        panelIzq.add(panelForm,    BorderLayout.CENTER);
        panelIzq.add(panelBotones, BorderLayout.SOUTH);

        add(panelIzq, BorderLayout.WEST);
        add(scroll,   BorderLayout.CENTER);

        cargarTabla();

        // --- SELECCIONAR FILA ---
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int fila = tabla.getSelectedRow();
                if (fila >= 0) {
                    idSeleccionado = (int) modeloTabla.getValueAt(fila, 0);
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtDescripcion.setText(modeloTabla.getValueAt(fila, 2).toString());
                    txtPrecio.setText(modeloTabla.getValueAt(fila, 3).toString());
                    txtStock.setText(modeloTabla.getValueAt(fila, 4).toString());
                    Object fecha = modeloTabla.getValueAt(fila, 5);
                    txtFecha.setText(fecha != null ? fecha.toString() : "");
                    cmbProveedor.setSelectedItem(modeloTabla.getValueAt(fila, 6));
                    cmbCategoria.setSelectedItem(modeloTabla.getValueAt(fila, 7));
                }
            }
        });

        // --- ACCION GUARDAR ---
        btnGuardar.addActionListener(e -> {
            try {
                Producto p = new Producto();
                p.setNombre(txtNombre.getText());
                p.setDescripcion(txtDescripcion.getText());
                p.setPrecio(Double.parseDouble(txtPrecio.getText()));
                p.setStock(Integer.parseInt(txtStock.getText()));
                p.setFechaVencimiento(txtFecha.getText().isEmpty() ? null :
                    new SimpleDateFormat("yyyy-MM-dd").parse(txtFecha.getText()));
                p.setIdProveedor(idProveedorSeleccionado);
                p.setIdCategoria(idCategoriaSeleccionada);
                if (dao.agregar(p)) {
                    JOptionPane.showMessageDialog(this, "Producto guardado");
                    cargarTabla();
                    limpiar();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Error: verifica los datos ingresados\n" + ex.getMessage());
            }
        });

        // --- ACCION ACTUALIZAR ---
        btnActualizar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un producto");
                return;
            }
            try {
                Producto p = new Producto();
                p.setIdProducto(idSeleccionado);
                p.setNombre(txtNombre.getText());
                p.setDescripcion(txtDescripcion.getText());
                p.setPrecio(Double.parseDouble(txtPrecio.getText()));
                p.setStock(Integer.parseInt(txtStock.getText()));
                p.setFechaVencimiento(txtFecha.getText().isEmpty() ? null :
                    new SimpleDateFormat("yyyy-MM-dd").parse(txtFecha.getText()));
                p.setIdProveedor(idProveedorSeleccionado);
                p.setIdCategoria(idCategoriaSeleccionada);
                if (dao.actualizar(p)) {
                    JOptionPane.showMessageDialog(this, "Producto actualizado");
                    cargarTabla();
                    limpiar();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Error: verifica los datos ingresados\n" + ex.getMessage());
            }
        });

        // --- ACCION ELIMINAR ---
        btnEliminar.addActionListener(e -> {
            if (idSeleccionado == -1) {
                JOptionPane.showMessageDialog(this, "Selecciona un producto");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(
                this, "¿Eliminar este producto?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                if (dao.eliminar(idSeleccionado)) {
                    JOptionPane.showMessageDialog(this, "Producto eliminado");
                    cargarTabla();
                    limpiar();
                }
            }
        });

        btnLimpiar.addActionListener(e -> limpiar());
        btnVolver.addActionListener(e -> this.dispose());
    }

    private void cargarCombos() {
        // Proveedores
        List<String[]> proveedores = dao.listarProveedores();
        for (String[] p : proveedores) {
            cmbProveedor.addItem(p[1]);
        }
        // Categorias
        List<String[]> categorias = dao.listarCategorias();
        for (String[] c : categorias) {
            cmbCategoria.addItem(c[1]);
        }

        // Guardar ID al seleccionar proveedor
        cmbProveedor.addActionListener(e -> {
            int idx = cmbProveedor.getSelectedIndex();
            if (idx >= 0) {
                idProveedorSeleccionado = Integer.parseInt(
                    dao.listarProveedores().get(idx)[0]);
            }
        });

        // Guardar ID al seleccionar categoría
        cmbCategoria.addActionListener(e -> {
            int idx = cmbCategoria.getSelectedIndex();
            if (idx >= 0) {
                idCategoriaSeleccionada = Integer.parseInt(
                    dao.listarCategorias().get(idx)[0]);
            }
        });
    }

    private void cargarTabla() {
        modeloTabla.setRowCount(0);
        List<Producto> lista = dao.listar();
        for (Producto p : lista) {
            modeloTabla.addRow(new Object[]{
                p.getIdProducto(),
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecio(),
                p.getStock(),
                p.getFechaVencimiento(),
                p.getNombreProveedor(),
                p.getNombreCategoria()
            });
        }
    }

    private void limpiar() {
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        txtFecha.setText("");
        cmbProveedor.setSelectedIndex(0);
        cmbCategoria.setSelectedIndex(0);
        idSeleccionado = -1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException |
                 javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ProductoVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
