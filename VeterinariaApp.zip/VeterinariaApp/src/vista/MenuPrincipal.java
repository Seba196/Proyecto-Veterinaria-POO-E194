/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import modelo.Usuario;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author USUARIO
 */
public class MenuPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MenuPrincipal.class.getName());
    private Usuario usuarioActual;
    
    /**
     * Creates new form MenuPrincipal
     */
    public MenuPrincipal(Usuario usuario) {
        initComponents();

        this.usuarioActual = usuario;
        setTitle("Veterinaria - Panel Administrativo");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- PANEL LATERAL (menú) ---
        JPanel panelMenu = new JPanel();
        panelMenu.setBackground(new Color(33, 97, 140));
        panelMenu.setPreferredSize(new Dimension(200, 600));
        panelMenu.setLayout(new GridLayout(9, 1, 5, 5));

        // Nombre y rol del usuario logueado
        JLabel lblNombre = new JLabel(
            "<html><center>" + usuario.getNombre() + "</center></html>",
            SwingConstants.CENTER);
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setFont(new Font("Arial", Font.BOLD, 12));

        JLabel lblRol = new JLabel(
            "[ " + usuario.getRol().toUpperCase() + " ]",
            SwingConstants.CENTER);
        lblRol.setForeground(new Color(174, 214, 241));
        lblRol.setFont(new Font("Arial", Font.ITALIC, 11));

        // Botones del menú
        JButton btnUsuarios    = crearBoton(">> Usuarios");
        JButton btnProductos   = crearBoton(">> Productos");
        JButton btnProveedores = crearBoton(">> Proveedores");
        JButton btnCategorias  = crearBoton(">> Categorias");
        JButton btnStock       = crearBoton(">> Movimientos");
        JButton btnSalir       = crearBoton("[ Cerrar Sesion ]");

        switch (usuario.getRol().toLowerCase()) {
            case "admin":
                // Admin tiene acceso a todo
                break;
            case "veterinario":
                // Solo ve productos, categorías y movimientos
                btnUsuarios.setEnabled(false);
                btnUsuarios.setToolTipText("Solo administradores");
                btnProveedores.setEnabled(false);
                btnProveedores.setToolTipText("Solo administradores");
                break;
            case "empleado":
                // Solo ve productos y movimientos
                btnUsuarios.setEnabled(false);
                btnUsuarios.setToolTipText("Solo administradores");
                btnProveedores.setEnabled(false);
                btnProveedores.setToolTipText("Solo administradores");
                btnCategorias.setEnabled(false);
                btnCategorias.setToolTipText("Solo administradores");
                break;
            default:
                btnUsuarios.setEnabled(false);
                btnProductos.setEnabled(false);
                btnProveedores.setEnabled(false);
                btnCategorias.setEnabled(false);
                btnStock.setEnabled(false);
                break;
        }

        panelMenu.add(lblNombre);
        panelMenu.add(lblRol);
        panelMenu.add(btnUsuarios);
        panelMenu.add(btnProductos);
        panelMenu.add(btnProveedores);
        panelMenu.add(btnCategorias);
        panelMenu.add(btnStock);
        panelMenu.add(new JLabel()); // espacio vacío
        panelMenu.add(btnSalir);

        // --- PANEL CONTENIDO ---
        JPanel panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBackground(Color.WHITE);

        JLabel lblBienvenida = new JLabel(
            "<html><center>Bienvenido, " + usuario.getNombre() +
            "<br><small>Selecciona una opción del menú</small></center></html>",
            SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("Arial", Font.PLAIN, 16));
        panelContenido.add(lblBienvenida, BorderLayout.CENTER);

        // --- ACCIONES DE LOS BOTONES ---
        btnUsuarios.addActionListener(e -> {
            new UsuarioVista().setVisible(true);
        });

        btnProductos.addActionListener(e -> {
            new ProductoVista().setVisible(true);
        });

        btnProveedores.addActionListener(e -> {
            new ProveedorVista().setVisible(true);
        });

        btnCategorias.addActionListener(e -> {
            new CategoriaVista().setVisible(true);
        });

        btnStock.addActionListener(e -> {
            new MovimientoVista().setVisible(true);
        });

        //Cerrar sesión ahora vuelve al Login
        btnSalir.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                this, "¿Deseas cerrar sesión?",
                "Cerrar Sesión", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                new LoginVista().setVisible(true);
                this.dispose();
            }
        });

        add(panelMenu,      BorderLayout.WEST);
        add(panelContenido, BorderLayout.CENTER);
    }

    // Método para crear botones con estilo
    private JButton crearBoton(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(new Color(52, 152, 219));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 13));
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
     
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LoginVista().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
