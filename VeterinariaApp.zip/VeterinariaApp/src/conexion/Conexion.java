/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author USUARIO
 */
public class Conexion {
    // Datos de la base de datos
    private static final String URL      = "jdbc:postgresql://localhost:5432/veterinaria_db";
    private static final String USUARIO  = "postgres";
    private static final String PASSWORD = "Sebastian123*"; // la que pusiste al instalar
    
    public static Connection getConexion() {
        Connection con = null;
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (Exception e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return con;
    }
}
