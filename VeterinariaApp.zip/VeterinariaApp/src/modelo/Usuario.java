/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
/**
 *
 * @author USUARIO
 */
public class Usuario {
    private int    idUsuario;
    private String nombre;
    private String correo;
    private String telefono;
    private String contrasena;
    private String rol;
    
    //Constructor vacío
    public Usuario() {}
    
    //Constructor completo
    public Usuario(int idUsuario, String nombre, String correo, 
                   String telefono, String contrasena, String rol) {
        this.idUsuario  = idUsuario;
        this.nombre     = nombre;
        this.correo     = correo;
        this.telefono   = telefono;
        this.contrasena = contrasena;
        this.rol        = rol;
    }
    
    //Getters y Setters
    public int    getIdUsuario()  { return idUsuario; }
    public String getNombre()     { return nombre; }
    public String getCorreo()     { return correo; }
    public String getTelefono()   { return telefono; }
    public String getContrasena() { return contrasena; }
    public String getRol()        { return rol; }
    
    public void setIdUsuario(int idUsuario)      { this.idUsuario  = idUsuario; }
    public void setNombre(String nombre)         { this.nombre     = nombre; }
    public void setCorreo(String correo)         { this.correo     = correo; }
    public void setTelefono(String telefono)     { this.telefono   = telefono; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public void setRol(String rol)               { this.rol        = rol; }
}
