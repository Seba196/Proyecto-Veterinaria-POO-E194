/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USUARIO
 */
public class Movimiento {
   private int    idMovimiento;
    private String tipo;
    private int    cantidad;
    private Date   fecha;
    private int    idProducto;
    private int    idUsuario;
    private String nombreProducto;
    private String nombreUsuario;

    public Movimiento() {}

    public Movimiento(int idMovimiento, String tipo, int cantidad,
                      Date fecha, int idProducto, int idUsuario) {
        this.idMovimiento = idMovimiento;
        this.tipo         = tipo;
        this.cantidad     = cantidad;
        this.fecha        = fecha;
        this.idProducto   = idProducto;
        this.idUsuario    = idUsuario;
    }

    public int    getIdMovimiento()   { return idMovimiento; }
    public String getTipo()           { return tipo; }
    public int    getCantidad()       { return cantidad; }
    public Date   getFecha()          { return fecha; }
    public int    getIdProducto()     { return idProducto; }
    public int    getIdUsuario()      { return idUsuario; }
    public String getNombreProducto() { return nombreProducto; }
    public String getNombreUsuario()  { return nombreUsuario; }

    public void setIdMovimiento(int idMovimiento)      { this.idMovimiento  = idMovimiento; }
    public void setTipo(String tipo)                   { this.tipo          = tipo; }
    public void setCantidad(int cantidad)              { this.cantidad      = cantidad; }
    public void setFecha(Date fecha)                   { this.fecha         = fecha; }
    public void setIdProducto(int idProducto)          { this.idProducto    = idProducto; }
    public void setIdUsuario(int idUsuario)            { this.idUsuario     = idUsuario; }
    public void setNombreProducto(String nombreProducto){ this.nombreProducto = nombreProducto; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }  
}
