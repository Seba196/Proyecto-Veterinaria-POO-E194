/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author USUARIO
 */
public class Producto {
  private int idProducto;
    private String nombre;
    private String descripcion;
    private double precio;
    private int stock;
    private Date fechaVencimiento;
    private int idProveedor;
    private int idCategoria;
    private String nombreProveedor;
    private String nombreCategoria;

    public Producto() {}

    public Producto(int idProducto, String nombre, String descripcion,
                    double precio, int stock, Date fechaVencimiento,
                    int idProveedor, int idCategoria) {
        this.idProducto       = idProducto;
        this.nombre           = nombre;
        this.descripcion      = descripcion;
        this.precio           = precio;
        this.stock            = stock;
        this.fechaVencimiento = fechaVencimiento;
        this.idProveedor      = idProveedor;
        this.idCategoria      = idCategoria;
    }

    // Getters y Setters
    public int    getIdProducto()        { return idProducto; }
    public String getNombre()            { return nombre; }
    public String getDescripcion()       { return descripcion; }
    public double getPrecio()            { return precio; }
    public int    getStock()             { return stock; }
    public Date   getFechaVencimiento()  { return fechaVencimiento; }
    public int    getIdProveedor()       { return idProveedor; }
    public int    getIdCategoria()       { return idCategoria; }
    public String getNombreProveedor()   { return nombreProveedor; }
    public String getNombreCategoria()   { return nombreCategoria; }

    public void setIdProducto(int idProducto)              { this.idProducto       = idProducto; }
    public void setNombre(String nombre)                   { this.nombre           = nombre; }
    public void setDescripcion(String descripcion)         { this.descripcion      = descripcion; }
    public void setPrecio(double precio)                   { this.precio           = precio; }
    public void setStock(int stock)                        { this.stock            = stock; }
    public void setFechaVencimiento(Date fechaVencimiento) { this.fechaVencimiento = fechaVencimiento; }
    public void setIdProveedor(int idProveedor)            { this.idProveedor      = idProveedor; }
    public void setIdCategoria(int idCategoria)            { this.idCategoria      = idCategoria; }
    public void setNombreProveedor(String nombreProveedor) { this.nombreProveedor  = nombreProveedor; }
    public void setNombreCategoria(String nombreCategoria) { this.nombreCategoria  = nombreCategoria; }  
}
