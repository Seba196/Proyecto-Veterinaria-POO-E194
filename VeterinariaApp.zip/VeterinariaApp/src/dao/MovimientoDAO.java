/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.Conexion;
import modelo.Movimiento;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class MovimientoDAO {
    private Connection con;

    public MovimientoDAO() {
        this.con = Conexion.getConexion();
    }

    // Registrar movimiento y actualizar stock
    public boolean registrar(Movimiento m) {
        try {
            con.setAutoCommit(false);

            // Insertar movimiento
            String sqlInsert = "INSERT INTO movimientos_stock "
                             + "(tipo, cantidad, id_producto, id_usuario) "
                             + "VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sqlInsert);
            ps.setString(1, m.getTipo());
            ps.setInt(2,    m.getCantidad());
            ps.setInt(3,    m.getIdProducto());
            ps.setInt(4,    m.getIdUsuario());
            ps.executeUpdate();

            // Actualizar stock según tipo
            String sqlStock;
            if (m.getTipo().equals("entrada")) {
                sqlStock = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
            } else {
                sqlStock = "UPDATE productos SET stock = stock - ? WHERE id_producto = ?";
            }
            PreparedStatement psStock = con.prepareStatement(sqlStock);
            psStock.setInt(1, m.getCantidad());
            psStock.setInt(2, m.getIdProducto());
            psStock.executeUpdate();

            con.commit();
            return true;
        } catch (SQLException e) {
            try { con.rollback(); } catch (SQLException ex) {}
            System.out.println("Error al registrar movimiento: " + e.getMessage());
            return false;
        } finally {
            try { con.setAutoCommit(true); } catch (SQLException e) {}
        }
    }

    // Listar todos los movimientos
    public List<Movimiento> listar() {
        return listarFiltrado(null, null, null);
    }

    // Listar con filtros opcionales
    public List<Movimiento> listarFiltrado(String producto, String fechaDesde, String fechaHasta) {
        List<Movimiento> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT ms.*, p.nombre AS nom_prod, u.nombre AS nom_usu "
          + "FROM movimientos_stock ms "
          + "LEFT JOIN productos p ON ms.id_producto = p.id_producto "
          + "LEFT JOIN usuarios u ON ms.id_usuario = u.id_usuario "
          + "WHERE 1=1 "
        );

        if (producto != null && !producto.isEmpty()) {
            sql.append("AND LOWER(p.nombre) LIKE LOWER('%").append(producto).append("%') ");
        }
        if (fechaDesde != null && !fechaDesde.isEmpty()) {
            sql.append("AND DATE(ms.fecha) >= '").append(fechaDesde).append("' ");
        }
        if (fechaHasta != null && !fechaHasta.isEmpty()) {
            sql.append("AND DATE(ms.fecha) <= '").append(fechaHasta).append("' ");
        }
        sql.append("ORDER BY ms.fecha DESC");

        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql.toString());
            while (rs.next()) {
                Movimiento m = new Movimiento(
                    rs.getInt("id_movimiento"),
                    rs.getString("tipo"),
                    rs.getInt("cantidad"),
                    rs.getTimestamp("fecha"),
                    rs.getInt("id_producto"),
                    rs.getInt("id_usuario")
                );
                m.setNombreProducto(rs.getString("nom_prod"));
                m.setNombreUsuario(rs.getString("nom_usu"));
                lista.add(m);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar movimientos: " + e.getMessage());
        }
        return lista;
    }

    // Listar productos para el combo
    public List<String[]> listarProductos() {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre FROM productos ORDER BY nombre";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                lista.add(new String[]{
                    rs.getString("id_producto"),
                    rs.getString("nombre")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error al listar productos: " + e.getMessage());
        }
        return lista;
    }

    // Listar usuarios para el combo
    public List<String[]> listarUsuarios() {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT id_usuario, nombre FROM usuarios ORDER BY nombre";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                lista.add(new String[]{
                    rs.getString("id_usuario"),
                    rs.getString("nombre")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
        }
        return lista;
    }
}
