/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.Conexion;
import modelo.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ProductoDAO {
  private Connection con;

    public ProductoDAO() {
        this.con = Conexion.getConexion();
    }

    public boolean agregar(Producto p) {
        String sql = "INSERT INTO productos (nombre, descripcion, precio, stock, "
                   + "fecha_vencimiento, id_proveedor, id_categoria) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4,    p.getStock());
            ps.setDate(5,   p.getFechaVencimiento() != null ?
                new java.sql.Date(p.getFechaVencimiento().getTime()) : null);
            ps.setInt(6,    p.getIdProveedor());
            ps.setInt(7,    p.getIdCategoria());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al agregar producto: " + e.getMessage());
            return false;
        }
    }

 //listar todos con nombre de proveedor y categoría
    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT p.*, pr.nombre AS nom_prov, c.nombre AS nom_cat "
                   + "FROM productos p "
                   + "LEFT JOIN proveedores pr ON p.id_proveedor = pr.id_proveedor "
                   + "LEFT JOIN categorias c ON p.id_categoria = c.id_categoria "
                   + "ORDER BY p.id_producto";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Producto p = new Producto(
                    rs.getInt("id_producto"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getDate("fecha_vencimiento"),
                    rs.getInt("id_proveedor"),
                    rs.getInt("id_categoria")
                );
                p.setNombreProveedor(rs.getString("nom_prov"));
                p.setNombreCategoria(rs.getString("nom_cat"));
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar productos: " + e.getMessage());
        }
        return lista;
    }

    //UPDATE
    public boolean actualizar(Producto p) {
        String sql = "UPDATE productos SET nombre=?, descripcion=?, precio=?, "
                   + "stock=?, fecha_vencimiento=?, id_proveedor=?, id_categoria=? "
                   + "WHERE id_producto=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4,    p.getStock());
            ps.setDate(5,   p.getFechaVencimiento() != null ?
                new java.sql.Date(p.getFechaVencimiento().getTime()) : null);
            ps.setInt(6,    p.getIdProveedor());
            ps.setInt(7,    p.getIdCategoria());
            ps.setInt(8,    p.getIdProducto());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    //DELETE
    public boolean eliminar(int idProducto) {
        String sql = "DELETE FROM productos WHERE id_producto=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    //Listar proveedores para el combo
    public List<String[]> listarProveedores() {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT id_proveedor, nombre FROM proveedores ORDER BY nombre";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                lista.add(new String[]{
                    rs.getString("id_proveedor"),
                    rs.getString("nombre")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error al listar proveedores: " + e.getMessage());
        }
        return lista;
    }

    //Listar categorías para el combo
    public List<String[]> listarCategorias() {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT id_categoria, nombre FROM categorias ORDER BY nombre";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                lista.add(new String[]{
                    rs.getString("id_categoria"),
                    rs.getString("nombre")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error al listar categorias: " + e.getMessage());
        }
        return lista;
    }  
}
