/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.Conexion;
import modelo.Proveedor;
import modelo.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ProveedorDAO {
    private Connection con;

    public ProveedorDAO() {
        this.con = Conexion.getConexion();
    }

    // CREATE
    public boolean agregar(Proveedor p) {
        String sql = "INSERT INTO proveedores (nombre, telefono, correo, direccion) "
                   + "VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTelefono());
            ps.setString(3, p.getCorreo());
            ps.setString(4, p.getDireccion());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al agregar proveedor: " + e.getMessage());
            return false;
        }
    }

    // READ
    public List<Proveedor> listar() {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT * FROM proveedores ORDER BY id_proveedor";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                lista.add(new Proveedor(
                    rs.getInt("id_proveedor"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo"),
                    rs.getString("direccion")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error al listar proveedores: " + e.getMessage());
        }
        return lista;
    }

    // UPDATE
    public boolean actualizar(Proveedor p) {
        String sql = "UPDATE proveedores SET nombre=?, telefono=?, correo=?, "
                   + "direccion=? WHERE id_proveedor=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTelefono());
            ps.setString(3, p.getCorreo());
            ps.setString(4, p.getDireccion());
            ps.setInt(5,    p.getIdProveedor());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al actualizar proveedor: " + e.getMessage());
            return false;
        }
    }

    // DELETE
    public boolean eliminar(int idProveedor) {
        String sql = "DELETE FROM proveedores WHERE id_proveedor=?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProveedor);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al eliminar proveedor: " + e.getMessage());
            return false;
        }
    }

    // Listar productos de un proveedor específico
    public List<Producto> listarProductosPorProveedor(int idProveedor) {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT p.*, c.nombre AS nom_cat FROM productos p "
                   + "LEFT JOIN categorias c ON p.id_categoria = c.id_categoria "
                   + "WHERE p.id_proveedor = ? ORDER BY p.nombre";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProveedor);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Producto p = new Producto(
                    rs.getInt("id_producto"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getDate("fecha_vencimiento"),
                    rs.getInt("id_proveedor"),
                    rs.getInt("id_categoria")
                );
                p.setNombreCategoria(rs.getString("nom_cat"));
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar productos del proveedor: " + e.getMessage());
        }
        return lista;
    }   
}
